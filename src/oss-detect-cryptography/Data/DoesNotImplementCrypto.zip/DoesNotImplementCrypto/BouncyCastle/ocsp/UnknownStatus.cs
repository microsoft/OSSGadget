using System;

namespace Org.BouncyCastle.Ocsp
{
	/**
	 * wrapper for the UnknownInfo object
	 */
	public class UnknownStatus
		: CertificateStatus
	{
		public UnknownStatus()
		{
		}
	}
}
