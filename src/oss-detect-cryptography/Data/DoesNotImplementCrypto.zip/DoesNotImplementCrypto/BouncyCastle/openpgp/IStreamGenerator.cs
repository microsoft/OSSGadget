namespace Org.BouncyCastle.Bcpg.OpenPgp
{
	public interface IStreamGenerator
	{
		void Close();
	}
}
