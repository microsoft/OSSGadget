namespace Org.BouncyCastle.Bcpg.OpenPgp
{
	public abstract class PgpObject
	{
		internal PgpObject()
		{
		}
	}
}
