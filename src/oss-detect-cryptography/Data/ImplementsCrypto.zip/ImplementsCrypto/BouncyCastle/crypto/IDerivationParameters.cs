using System;

namespace Org.BouncyCastle.Crypto
{
    /**
     * Parameters for key/byte stream derivation classes
     */
    public interface IDerivationParameters
    {
    }
}
