﻿using System;

using Org.BouncyCastle.Security;

namespace Org.BouncyCastle.Crypto.Tls
{
    public interface TlsServerContext
        : TlsContext
    {
    }
}
